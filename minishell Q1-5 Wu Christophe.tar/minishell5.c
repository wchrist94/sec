# include <stdio.h>
# include <unistd.h>
# include <stdlib.h>
# include <sys/wait.h>
# include <string.h>
# include <limits.h>
# include "readcmd.h"

char cwd[PATH_MAX];
int codeTerm;
struct cmdline * cmd; // commande à lire
pid_t pidFils; // pid du fils


int main() {
  while (1) {

    // Affichage de l'invite
    getcwd(cwd, sizeof(cwd));
    printf("cwu3@minishell:~%s$ ", cwd);
    fflush(stdout);

    // Lecture de cmd en utlisant readcmd.h
    cmd = readcmd();

    if (cmd != NULL) {
      if ((cmd->seq)[0] != NULL) {
        // Commande exit ne nécessitant pas de fils
        if (!strcmp((cmd->seq)[0][0], "exit") && !(cmd->backgrounded)) {
          exit(0);
        // Commande cd ne nécessitant pas de fils
        } else if (!strcmp((cmd->seq)[0][0], "cd") && !(cmd->backgrounded)) {
          chdir((cmd->seq)[0][1]);
        }

        pidFils = fork();

        // Erreur
        if (pidFils < 0) {
          exit(1);
        }

        if (pidFils == 0) {
          execvp((cmd->seq)[0][0], (cmd->seq)[0]);
          exit(1);
        } else {
          // Gestion du chevauchement
          if (!(cmd->backgrounded)) {
            pid_t idFils = wait(&codeTerm);
            if (idFils == -1) {
              perror("wait...");
              exit(2);
            }
            // if (WEXITSTATUS(codeTerm) == 1) {
            //     printf("Echec d'éxecution de la commande\n");
            // }
          }
        }
      }
    }
  }
  return EXIT_SUCCESS;
}
